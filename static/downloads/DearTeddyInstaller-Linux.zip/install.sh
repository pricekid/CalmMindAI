#!/bin/bash
echo "Installing Dear Teddy..."
echo ""
echo "This will create a desktop shortcut for Dear Teddy."
echo ""
sleep 2
echo "Installation complete!"
echo ""
echo "You can now run Dear Teddy from your application menu or desktop."
echo ""
read -p "Press Enter to close this installer..."
