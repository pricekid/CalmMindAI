# Dear Teddy for Linux

1. Extract this archive
2. Run ./install.sh to complete the installation
3. Launch Dear Teddy from your applications menu

Thank you for choosing Dear Teddy!
