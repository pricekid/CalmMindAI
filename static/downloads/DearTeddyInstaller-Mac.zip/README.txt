# Dear Teddy Installation

This package contains the Dear Teddy app for macOS.

## Installation
1. Drag the DearTeddy app to your Applications folder
2. When you first open the app, macOS may show a security warning
3. If you see 'DearTeddy cannot be opened because the developer cannot be verified':
   - Right-click (or Control-click) on the app icon and select 'Open'
   - Click 'Open' in the dialog box that appears
4. The app will now open and you won't see this warning again

Thank you for using Dear Teddy!
