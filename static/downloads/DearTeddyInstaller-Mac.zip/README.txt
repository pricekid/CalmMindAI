# IMPORTANT: macOS Security Instructions

## To Install Dear Teddy:

1. Extract this ZIP file
2. Drag the DearTeddy app to your Applications folder
3. When you try to open the app, macOS will show a security warning
4. **Do NOT click 'Move to Bin'** - this will delete the app
5. Instead, follow these steps:

### Method 1 (Recommended):
- Right-click (or Control-click) on the DearTeddy app icon
- Select 'Open' from the context menu
- When prompted, click 'Open'

### Method 2 (If Method 1 doesn't work):
- Close the warning by clicking 'Cancel'
- Open System Preferences > Security & Privacy
- Look for the message about DearTeddy being blocked
- Click 'Open Anyway'
- Click 'Open' when prompted

The app will now open and you won't see this warning again.

## About This App
Dear Teddy is your personal AI journaling companion. This desktop app provides easy access to your journal, mood tracking, and personalized insights.

Need help? Visit dearteddy-4vqj.onrender.com/support
