# Dear Teddy Installation

This package contains the Dear Teddy app for macOS.

## Installation
1. Simply drag the DearTeddy app to your Applications folder.
2. Double-click to launch.

Thank you for using Dear Teddy!
