This is a demo installer for Dear Teddy
