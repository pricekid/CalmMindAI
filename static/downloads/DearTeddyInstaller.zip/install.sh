#!/bin/sh
echo "Dear Teddy is now installing..."
sleep 2
echo "Installation complete!"
echo "Your Dear Teddy app is now ready to use."
