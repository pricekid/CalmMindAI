# Dear Teddy for Windows

1. Double-click Install.bat to complete the installation
2. A shortcut will be created on your desktop
3. Click the shortcut to start using Dear Teddy

Thank you for choosing Dear Teddy!
